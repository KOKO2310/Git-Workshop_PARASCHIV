# Git-Workshop

## TODO list:
  - [ ] move all classes to classes.hpp  
  - [ ] fix include path
  - [ ] fix main  
  - [ ] implement average grade method
